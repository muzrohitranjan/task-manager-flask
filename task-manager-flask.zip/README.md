# Task Manager Flask App

A simple task manager web app built using Python Flask and SQLite.

## Features
- Add tasks
- Delete tasks
- View all tasks

## How to Run
```bash
pip install flask
python app.py
```
